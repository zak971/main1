"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { Edit, Trash2, Plus, Loader2 } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { useToast } from "@/components/ui/use-toast"
import type { CarType } from "@/types/car"
import { getCars, addCar, updateCar, deleteCar } from "@/lib/cars"

export default function AdminPage() {
  const [cars, setCars] = useState<CarType[]>([])
  const [loading, setLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [editingCar, setEditingCar] = useState<CarType | null>(null)
  const [dialogOpen, setDialogOpen] = useState(false)
  const { toast } = useToast()
  const router = useRouter()

  // Form state
  const [formData, setFormData] = useState({
    name: "",
    price: "",
    seats: "",
    transmission: "Automatic",
    fuelType: "Petrol",
    featured: false,
    image: "",
  })

  useEffect(() => {
    async function loadCars() {
      try {
        const allCars = await getCars()
        setCars(allCars)
      } catch (error) {
        console.error("Failed to load cars:", error)
        toast({
          title: "Error",
          description: "Failed to load cars. Please try again.",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    // Check if user is authenticated (simplified for demo)
    const isAuthenticated = true // In a real app, check session/token
    if (!isAuthenticated) {
      router.push("/admin/login")
      return
    }

    loadCars()
  }, [router, toast])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target
    setFormData({
      ...formData,
      [name]: type === "checkbox" ? checked : value,
    })
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData({
      ...formData,
      [name]: value,
    })
  }

  const resetForm = () => {
    setFormData({
      name: "",
      price: "",
      seats: "",
      transmission: "Automatic",
      fuelType: "Petrol",
      featured: false,
      image: "",
    })
    setEditingCar(null)
  }

  const handleEdit = (car: CarType) => {
    setEditingCar(car)
    setFormData({
      name: car.name,
      price: car.price.toString(),
      seats: car.seats.toString(),
      transmission: car.transmission,
      fuelType: car.fuelType,
      featured: car.featured || false,
      image: car.image || "",
    })
    setDialogOpen(true)
  }

  const handleDelete = async (id: string) => {
    if (window.confirm("Are you sure you want to delete this car?")) {
      try {
        await deleteCar(id)
        setCars(cars.filter((car) => car.id !== id))
        toast({
          title: "Success",
          description: "Car deleted successfully",
        })
      } catch (error) {
        console.error("Failed to delete car:", error)
        toast({
          title: "Error",
          description: "Failed to delete car. Please try again.",
          variant: "destructive",
        })
      }
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      const carData = {
        name: formData.name,
        price: Number.parseInt(formData.price),
        seats: Number.parseInt(formData.seats),
        transmission: formData.transmission,
        fuelType: formData.fuelType,
        featured: formData.featured,
        image: formData.image,
      }

      if (editingCar) {
        // Update existing car
        const updatedCar = await updateCar(editingCar.id, carData)
        setCars(cars.map((car) => (car.id === editingCar.id ? updatedCar : car)))
        toast({
          title: "Success",
          description: "Car updated successfully",
        })
      } else {
        // Add new car
        const newCar = await addCar(carData)
        setCars([...cars, newCar])
        toast({
          title: "Success",
          description: "Car added successfully",
        })
      }

      resetForm()
      setDialogOpen(false)
    } catch (error) {
      console.error("Failed to save car:", error)
      toast({
        title: "Error",
        description: "Failed to save car. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    )
  }

  return (
    <div className="container px-4 py-12 mx-auto">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold">Admin Dashboard</h1>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-orange-500 hover:bg-orange-600">
              <Plus className="w-4 h-4 mr-2" />
              Add New Car
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[550px]">
            <DialogHeader>
              <DialogTitle>{editingCar ? "Edit Car" : "Add New Car"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  <Label htmlFor="name">Car Name</Label>
                  <Input id="name" name="name" value={formData.name} onChange={handleInputChange} required />
                </div>

                <div>
                  <Label htmlFor="price">Price per Day (₹)</Label>
                  <Input
                    id="price"
                    name="price"
                    type="number"
                    value={formData.price}
                    onChange={handleInputChange}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="seats">Number of Seats</Label>
                  <Input
                    id="seats"
                    name="seats"
                    type="number"
                    value={formData.seats}
                    onChange={handleInputChange}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="transmission">Transmission</Label>
                  <Select
                    value={formData.transmission}
                    onValueChange={(value) => handleSelectChange("transmission", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select transmission" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Automatic">Automatic</SelectItem>
                      <SelectItem value="Manual">Manual</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="fuelType">Fuel Type</Label>
                  <Select value={formData.fuelType} onValueChange={(value) => handleSelectChange("fuelType", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select fuel type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Petrol">Petrol</SelectItem>
                      <SelectItem value="Diesel">Diesel</SelectItem>
                      <SelectItem value="Electric">Electric</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="col-span-2">
                  <Label htmlFor="image">Image URL</Label>
                  <Input
                    id="image"
                    name="image"
                    value={formData.image}
                    onChange={handleInputChange}
                    placeholder="/images/car-name.jpg"
                  />
                </div>

                <div className="flex items-center col-span-2 space-x-2">
                  <input
                    type="checkbox"
                    id="featured"
                    name="featured"
                    checked={formData.featured}
                    onChange={handleInputChange}
                    className="w-4 h-4"
                  />
                  <Label htmlFor="featured">Featured Car</Label>
                </div>
              </div>

              <div className="flex justify-end space-x-3">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    resetForm()
                    setDialogOpen(false)
                  }}
                >
                  Cancel
                </Button>
                <Button type="submit" className="bg-orange-500 hover:bg-orange-600" disabled={isSubmitting}>
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Saving...
                    </>
                  ) : editingCar ? (
                    "Update Car"
                  ) : (
                    "Add Car"
                  )}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="cars">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="cars">Manage Cars</TabsTrigger>
          <TabsTrigger value="inquiries">Customer Inquiries</TabsTrigger>
        </TabsList>

        <TabsContent value="cars" className="mt-6">
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
            {cars.map((car) => (
              <Card key={car.id}>
                <div className="relative w-full h-48">
                  <Image
                    src={car.image || "/images/car-placeholder.jpg"}
                    alt={car.name}
                    fill
                    className="object-cover rounded-t-lg"
                  />
                </div>
                <CardHeader>
                  <CardTitle>{car.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <p className="text-2xl font-bold text-orange-500">₹{car.price}/day</p>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div>Seats: {car.seats}</div>
                      <div>Transmission: {car.transmission}</div>
                      <div>Fuel: {car.fuelType}</div>
                      <div>Featured: {car.featured ? "Yes" : "No"}</div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button variant="outline" size="sm" onClick={() => handleEdit(car)}>
                    <Edit className="w-4 h-4 mr-2" />
                    Edit
                  </Button>
                  <Button variant="destructive" size="sm" onClick={() => handleDelete(car.id)}>
                    <Trash2 className="w-4 h-4 mr-2" />
                    Delete
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="inquiries" className="mt-6">
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-gray-100">
                  <th className="p-3 text-left">Name</th>
                  <th className="p-3 text-left">Email</th>
                  <th className="p-3 text-left">Phone</th>
                  <th className="p-3 text-left">Car Type</th>
                  <th className="p-3 text-left">Date</th>
                  <th className="p-3 text-left">Status</th>
                  <th className="p-3 text-left">Actions</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b">
                  <td className="p-3">Rahul Sharma</td>
                  <td className="p-3">rahul@example.com</td>
                  <td className="p-3">+91 98765 43210</td>
                  <td className="p-3">SUV</td>
                  <td className="p-3">2023-04-15</td>
                  <td className="p-3">
                    <span className="px-2 py-1 text-xs text-white bg-yellow-500 rounded-full">Pending</span>
                  </td>
                  <td className="p-3">
                    <Button variant="ghost" size="sm">
                      View
                    </Button>
                  </td>
                </tr>
                <tr className="border-b">
                  <td className="p-3">Priya Patel</td>
                  <td className="p-3">priya@example.com</td>
                  <td className="p-3">+91 87654 32109</td>
                  <td className="p-3">Sedan</td>
                  <td className="p-3">2023-04-14</td>
                  <td className="p-3">
                    <span className="px-2 py-1 text-xs text-white bg-green-500 rounded-full">Responded</span>
                  </td>
                  <td className="p-3">
                    <Button variant="ghost" size="sm">
                      View
                    </Button>
                  </td>
                </tr>
                <tr className="border-b">
                  <td className="p-3">Michael Brown</td>
                  <td className="p-3">michael@example.com</td>
                  <td className="p-3">+44 7911 123456</td>
                  <td className="p-3">Luxury</td>
                  <td className="p-3">2023-04-13</td>
                  <td className="p-3">
                    <span className="px-2 py-1 text-xs text-white bg-blue-500 rounded-full">Booked</span>
                  </td>
                  <td className="p-3">
                    <Button variant="ghost" size="sm">
                      View
                    </Button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
