import type { Metadata } from "next"
import Link from "next/link"
import Image from "next/image"
import { notFound } from "next/navigation"
import { Car, Users, Fuel, Settings, Check, Phone, PhoneIcon as WhatsApp } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { getCar } from "@/lib/cars"

export async function generateMetadata({ params }: { params: { id: string } }): Promise<Metadata> {
  const car = await getCar(params.id)

  if (!car) {
    return {
      title: "Car Not Found - Goa Car Rentals",
    }
  }

  return {
    title: `${car.name} - Goa Car Rentals`,
    description: `Rent the ${car.name} in Goa. ${car.seats} seater, ${car.transmission} transmission, ${car.fuelType} engine. Book now for your Goa trip.`,
  }
}

export default async function CarDetailPage({ params }: { params: { id: string } }) {
  const car = await getCar(params.id)

  if (!car) {
    notFound()
  }

  return (
    <div className="container px-4 py-12 mx-auto">
      <div className="grid grid-cols-1 gap-8 lg:grid-cols-2">
        <div>
          <div className="relative w-full overflow-hidden rounded-lg aspect-video">
            <Image
              src={car.image || "/images/car-placeholder.jpg"}
              alt={car.name}
              fill
              priority
              className="object-cover"
            />
          </div>

          <div className="grid grid-cols-4 gap-4 mt-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="relative overflow-hidden rounded-lg cursor-pointer aspect-square">
                <Image
                  src={car.image || "/images/car-placeholder.jpg"}
                  alt={`${car.name} view ${i + 1}`}
                  fill
                  className="object-cover"
                />
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-6">
          <div>
            <h1 className="text-3xl font-bold">{car.name}</h1>
            <p className="mt-2 text-3xl font-bold text-orange-500">₹{car.price}/day</p>
          </div>

          <div className="grid grid-cols-2 gap-6">
            <div className="flex items-center">
              <Users className="w-6 h-6 mr-3 text-orange-500" />
              <div>
                <p className="text-sm text-gray-500">Seats</p>
                <p className="font-medium">{car.seats} Persons</p>
              </div>
            </div>

            <div className="flex items-center">
              <Settings className="w-6 h-6 mr-3 text-orange-500" />
              <div>
                <p className="text-sm text-gray-500">Transmission</p>
                <p className="font-medium">{car.transmission}</p>
              </div>
            </div>

            <div className="flex items-center">
              <Fuel className="w-6 h-6 mr-3 text-orange-500" />
              <div>
                <p className="text-sm text-gray-500">Fuel Type</p>
                <p className="font-medium">{car.fuelType}</p>
              </div>
            </div>

            <div className="flex items-center">
              <Car className="w-6 h-6 mr-3 text-orange-500" />
              <div>
                <p className="text-sm text-gray-500">Air Conditioning</p>
                <p className="font-medium">Yes</p>
              </div>
            </div>
          </div>

          <div className="p-6 bg-gray-50 rounded-lg">
            <h3 className="mb-4 text-lg font-medium">Car Features</h3>
            <div className="grid grid-cols-2 gap-3">
              <div className="flex items-center">
                <Check className="w-5 h-5 mr-2 text-green-500" />
                <span>Power Steering</span>
              </div>
              <div className="flex items-center">
                <Check className="w-5 h-5 mr-2 text-green-500" />
                <span>Power Windows</span>
              </div>
              <div className="flex items-center">
                <Check className="w-5 h-5 mr-2 text-green-500" />
                <span>Central Locking</span>
              </div>
              <div className="flex items-center">
                <Check className="w-5 h-5 mr-2 text-green-500" />
                <span>Bluetooth</span>
              </div>
              <div className="flex items-center">
                <Check className="w-5 h-5 mr-2 text-green-500" />
                <span>USB Charging</span>
              </div>
              <div className="flex items-center">
                <Check className="w-5 h-5 mr-2 text-green-500" />
                <span>GPS Navigation</span>
              </div>
            </div>
          </div>

          <div className="flex flex-col space-y-3 sm:flex-row sm:space-y-0 sm:space-x-3">
            <Button asChild size="lg" className="bg-orange-500 hover:bg-orange-600">
              <Link href={`https://wa.me/919876543210?text=I'm%20interested%20in%20renting%20the%20${car.name}`}>
                <WhatsApp className="w-5 h-5 mr-2" />
                Book on WhatsApp
              </Link>
            </Button>
            <Button asChild size="lg" variant="outline">
              <Link href="tel:+919876543210">
                <Phone className="w-5 h-5 mr-2" />
                Call to Book
              </Link>
            </Button>
          </div>
        </div>
      </div>

      <div className="mt-12">
        <Tabs defaultValue="description">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="description">Description</TabsTrigger>
            <TabsTrigger value="rental-terms">Rental Terms</TabsTrigger>
            <TabsTrigger value="reviews">Reviews</TabsTrigger>
          </TabsList>
          <TabsContent value="description" className="p-6 mt-6 border rounded-lg">
            <h3 className="mb-4 text-xl font-medium">{car.name} Overview</h3>
            <p className="mb-4 text-gray-600">
              The {car.name} is a {car.seats}-seater vehicle with {car.transmission} transmission and a {car.fuelType}{" "}
              engine. It's perfect for exploring the beautiful beaches and narrow roads of Goa.
            </p>
            <p className="mb-4 text-gray-600">
              This car offers excellent fuel efficiency, making it economical for longer trips around Goa. The spacious
              interior ensures comfort for all passengers, while the reliable performance guarantees a smooth driving
              experience.
            </p>
            <p className="text-gray-600">
              All our vehicles are regularly serviced and maintained to the highest standards to ensure your safety and
              comfort during your trip.
            </p>
          </TabsContent>
          <TabsContent value="rental-terms" className="p-6 mt-6 border rounded-lg">
            <h3 className="mb-4 text-xl font-medium">Rental Terms & Conditions</h3>
            <div className="space-y-4">
              <div>
                <h4 className="font-medium">Required Documents</h4>
                <ul className="pl-5 mt-2 space-y-1 list-disc text-gray-600">
                  <li>Valid driving license</li>
                  <li>Valid ID proof (Passport/Aadhar/Voter ID)</li>
                  <li>Address proof</li>
                </ul>
              </div>

              <div>
                <h4 className="font-medium">Rental Policies</h4>
                <ul className="pl-5 mt-2 space-y-1 list-disc text-gray-600">
                  <li>Minimum rental period: 24 hours</li>
                  <li>Security deposit: ₹5000 (refundable)</li>
                  <li>Fuel policy: Same to same</li>
                  <li>Late return fee: ₹500 per hour</li>
                  <li>Cancellation: Free up to 24 hours before pickup</li>
                </ul>
              </div>

              <div>
                <h4 className="font-medium">Insurance Coverage</h4>
                <p className="mt-2 text-gray-600">
                  Basic insurance is included in the rental price. Additional comprehensive insurance can be purchased
                  at ₹300 per day.
                </p>
              </div>
            </div>
          </TabsContent>
          <TabsContent value="reviews" className="p-6 mt-6 border rounded-lg">
            <h3 className="mb-4 text-xl font-medium">Customer Reviews</h3>
            <div className="space-y-6">
              <div className="p-4 border rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center">
                    <div className="w-10 h-10 mr-3 overflow-hidden bg-gray-200 rounded-full">
                      <Image
                        src="/images/avatar-1.jpg"
                        alt="Reviewer"
                        width={40}
                        height={40}
                        className="object-cover"
                      />
                    </div>
                    <div>
                      <p className="font-medium">Rahul Sharma</p>
                      <p className="text-sm text-gray-500">2 weeks ago</p>
                    </div>
                  </div>
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <svg key={i} className="w-5 h-5 text-yellow-400 fill-current" viewBox="0 0 24 24">
                        <path d="M12 17.27L18.18 21L16.54 13.97L22 9.24L14.81 8.63L12 2L9.19 8.63L2 9.24L7.46 13.97L5.82 21L12 17.27Z" />
                      </svg>
                    ))}
                  </div>
                </div>
                <p className="text-gray-600">
                  Great car! It was clean, well-maintained and perfect for our family trip around Goa. The pickup and
                  drop-off process was smooth and the staff was very helpful.
                </p>
              </div>

              <div className="p-4 border rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center">
                    <div className="w-10 h-10 mr-3 overflow-hidden bg-gray-200 rounded-full">
                      <Image
                        src="/images/avatar-2.jpg"
                        alt="Reviewer"
                        width={40}
                        height={40}
                        className="object-cover"
                      />
                    </div>
                    <div>
                      <p className="font-medium">Priya Patel</p>
                      <p className="text-sm text-gray-500">1 month ago</p>
                    </div>
                  </div>
                  <div className="flex">
                    {[...Array(4)].map((_, i) => (
                      <svg key={i} className="w-5 h-5 text-yellow-400 fill-current" viewBox="0 0 24 24">
                        <path d="M12 17.27L18.18 21L16.54 13.97L22 9.24L14.81 8.63L12 2L9.19 8.63L2 9.24L7.46 13.97L5.82 21L12 17.27Z" />
                      </svg>
                    ))}
                    <svg className="w-5 h-5 text-gray-300 fill-current" viewBox="0 0 24 24">
                      <path d="M12 17.27L18.18 21L16.54 13.97L22 9.24L14.81 8.63L12 2L9.19 8.63L2 9.24L7.46 13.97L5.82 21L12 17.27Z" />
                    </svg>
                  </div>
                </div>
                <p className="text-gray-600">
                  Good experience overall. The car was in good condition and fuel-efficient. The only issue was a slight
                  delay during pickup, but the staff was apologetic and professional.
                </p>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      <div className="p-6 mt-12 text-center bg-gray-50 rounded-lg">
        <h3 className="mb-4 text-xl font-medium">Need Help?</h3>
        <p className="mb-6 text-gray-600">
          Our customer support team is available to assist you with any questions or concerns.
        </p>
        <div className="flex flex-col justify-center space-y-3 sm:flex-row sm:space-y-0 sm:space-x-3">
          <Button asChild variant="outline">
            <Link href="tel:+919876543210">
              <Phone className="w-5 h-5 mr-2" />
              Call Us
            </Link>
          </Button>
          <Button asChild className="bg-green-600 hover:bg-green-700">
            <Link href="https://wa.me/919876543210?text=I%20have%20a%20question%20about%20renting%20a%20car%20in%20Goa">
              <WhatsApp className="w-5 h-5 mr-2" />
              WhatsApp Support
            </Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
