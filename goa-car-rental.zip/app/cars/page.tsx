import type { Metadata } from "next"
import Link from "next/link"
import Image from "next/image"
import { Car, Users, Fuel, Settings, Filter } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { getCars } from "@/lib/cars"

export const metadata: Metadata = {
  title: "Our Cars - Goa Car Rentals",
  description:
    "Browse our fleet of well-maintained cars available for rent in Goa. From economy cars to luxury vehicles, we have the perfect car for your Goa trip.",
}

export default async function CarsPage() {
  const cars = await getCars()

  return (
    <div className="container px-4 py-12 mx-auto">
      <div className="flex flex-col items-center mb-12 text-center">
        <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">Our Car Fleet</h1>
        <p className="mt-4 text-lg text-gray-600">Choose from our wide range of well-maintained vehicles</p>
      </div>

      <div className="grid grid-cols-1 gap-8 mb-12 md:grid-cols-4">
        <div className="p-6 bg-gray-50 rounded-lg md:col-span-1">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-medium">Filters</h2>
            <Filter className="w-5 h-5" />
          </div>

          <div className="space-y-6">
            <div>
              <h3 className="mb-3 font-medium">Car Type</h3>
              <div className="space-y-2">
                <div className="flex items-center">
                  <input type="checkbox" id="economy" className="mr-2" />
                  <label htmlFor="economy">Economy</label>
                </div>
                <div className="flex items-center">
                  <input type="checkbox" id="sedan" className="mr-2" />
                  <label htmlFor="sedan">Sedan</label>
                </div>
                <div className="flex items-center">
                  <input type="checkbox" id="suv" className="mr-2" />
                  <label htmlFor="suv">SUV</label>
                </div>
                <div className="flex items-center">
                  <input type="checkbox" id="luxury" className="mr-2" />
                  <label htmlFor="luxury">Luxury</label>
                </div>
                <div className="flex items-center">
                  <input type="checkbox" id="minivan" className="mr-2" />
                  <label htmlFor="minivan">Minivan</label>
                </div>
              </div>
            </div>

            <div>
              <h3 className="mb-3 font-medium">Transmission</h3>
              <div className="space-y-2">
                <div className="flex items-center">
                  <input type="checkbox" id="automatic" className="mr-2" />
                  <label htmlFor="automatic">Automatic</label>
                </div>
                <div className="flex items-center">
                  <input type="checkbox" id="manual" className="mr-2" />
                  <label htmlFor="manual">Manual</label>
                </div>
              </div>
            </div>

            <div>
              <h3 className="mb-3 font-medium">Fuel Type</h3>
              <div className="space-y-2">
                <div className="flex items-center">
                  <input type="checkbox" id="petrol" className="mr-2" />
                  <label htmlFor="petrol">Petrol</label>
                </div>
                <div className="flex items-center">
                  <input type="checkbox" id="diesel" className="mr-2" />
                  <label htmlFor="diesel">Diesel</label>
                </div>
                <div className="flex items-center">
                  <input type="checkbox" id="electric" className="mr-2" />
                  <label htmlFor="electric">Electric</label>
                </div>
              </div>
            </div>

            <div>
              <h3 className="mb-3 font-medium">Price Range</h3>
              <div className="space-y-2">
                <div className="flex items-center">
                  <input type="checkbox" id="price-1" className="mr-2" />
                  <label htmlFor="price-1">₹1000 - ₹2000</label>
                </div>
                <div className="flex items-center">
                  <input type="checkbox" id="price-2" className="mr-2" />
                  <label htmlFor="price-2">₹2000 - ₹3000</label>
                </div>
                <div className="flex items-center">
                  <input type="checkbox" id="price-3" className="mr-2" />
                  <label htmlFor="price-3">₹3000 - ₹5000</label>
                </div>
                <div className="flex items-center">
                  <input type="checkbox" id="price-4" className="mr-2" />
                  <label htmlFor="price-4">₹5000+</label>
                </div>
              </div>
            </div>

            <Button className="w-full bg-orange-500 hover:bg-orange-600">Apply Filters</Button>
          </div>
        </div>

        <div className="md:col-span-3">
          <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {cars.map((car) => (
              <Card key={car.id} className="overflow-hidden transition-all duration-300 hover:shadow-lg">
                <div className="relative w-full h-48">
                  <Image
                    src={car.image || "/images/car-placeholder.jpg"}
                    alt={car.name}
                    fill
                    className="object-cover"
                  />
                  {car.featured && <Badge className="absolute top-2 right-2 bg-orange-500">Featured</Badge>}
                </div>
                <CardContent className="p-6">
                  <h3 className="mb-2 text-xl font-bold">{car.name}</h3>
                  <p className="mb-4 text-2xl font-bold text-orange-500">₹{car.price}/day</p>

                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div className="flex items-center">
                      <Users className="w-5 h-5 mr-2 text-gray-500" />
                      <span>{car.seats} Seats</span>
                    </div>
                    <div className="flex items-center">
                      <Settings className="w-5 h-5 mr-2 text-gray-500" />
                      <span>{car.transmission}</span>
                    </div>
                    <div className="flex items-center">
                      <Fuel className="w-5 h-5 mr-2 text-gray-500" />
                      <span>{car.fuelType}</span>
                    </div>
                    <div className="flex items-center">
                      <Car className="w-5 h-5 mr-2 text-gray-500" />
                      <span>A/C</span>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="p-6 pt-0">
                  <div className="flex flex-col w-full space-y-2 sm:flex-row sm:space-y-0 sm:space-x-2">
                    <Button asChild variant="outline" className="flex-1">
                      <Link href={`/cars/${car.id}`}>Details</Link>
                    </Button>
                    <Button asChild className="flex-1 bg-orange-500 hover:bg-orange-600">
                      <Link
                        href={`https://wa.me/919876543210?text=I'm%20interested%20in%20renting%20the%20${car.name}`}
                      >
                        Book Now
                      </Link>
                    </Button>
                  </div>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
