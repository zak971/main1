import Link from "next/link"
import Image from "next/image"
import { Phone, PhoneIcon as WhatsApp, Mail, ChevronRight, MapPin, Star } from "lucide-react"

import { Button } from "@/components/ui/button"
import { FeaturedCars } from "@/components/featured-cars"
import { TestimonialSlider } from "@/components/testimonial-slider"
import { ContactForm } from "@/components/contact-form"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative w-full h-[80vh] bg-gradient-to-r from-black to-black/70">
        <Image
          src="/images/hero-bg.jpg"
          alt="Goa beaches with luxury cars"
          fill
          priority
          className="object-cover mix-blend-overlay"
        />
        <div className="container relative z-10 flex flex-col items-start justify-center h-full px-4 mx-auto space-y-6 text-white">
          <h1 className="text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl">Explore Goa In Style</h1>
          <p className="max-w-xl text-lg text-gray-200 md:text-xl">
            Premium car rentals at affordable prices. Experience the beauty of Goa with comfort and luxury.
          </p>
          <div className="flex flex-col space-y-3 sm:flex-row sm:space-y-0 sm:space-x-4">
            <Button size="lg" className="bg-orange-500 hover:bg-orange-600">
              View Cars
            </Button>
            <Button size="lg" variant="outline" className="text-white border-white hover:bg-white/10">
              <WhatsApp className="w-5 h-5 mr-2" />
              <Link href="https://wa.me/919876543210?text=I'm%20interested%20in%20renting%20a%20car%20in%20Goa">
                WhatsApp Now
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Quick Contact Bar */}
      <section className="w-full py-4 bg-orange-500 text-white">
        <div className="container flex flex-wrap items-center justify-between px-4 mx-auto">
          <div className="flex items-center space-x-2">
            <MapPin className="w-5 h-5" />
            <span className="text-sm font-medium">Calangute, Goa, India</span>
          </div>
          <div className="flex flex-wrap items-center space-x-4">
            <Link href="tel:+919876543210" className="flex items-center space-x-2 hover:underline">
              <Phone className="w-5 h-5" />
              <span className="text-sm font-medium">+91 98765 43210</span>
            </Link>
            <Link href="mailto:info@goacarrentals.com" className="flex items-center space-x-2 hover:underline">
              <Mail className="w-5 h-5" />
              <span className="text-sm font-medium">info@goacarrentals.com</span>
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Cars Section */}
      <section className="py-16 bg-gray-50">
        <div className="container px-4 mx-auto">
          <div className="flex flex-col items-center mb-12 text-center">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Our Premium Fleet</h2>
            <p className="mt-4 text-lg text-gray-600">Choose from our wide range of well-maintained vehicles</p>
          </div>
          <FeaturedCars />
          <div className="flex justify-center mt-12">
            <Button asChild size="lg">
              <Link href="/cars">
                View All Cars <ChevronRight className="w-4 h-4 ml-2" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 bg-white">
        <div className="container px-4 mx-auto">
          <div className="flex flex-col items-center mb-12 text-center">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Why Choose Us</h2>
            <p className="mt-4 text-lg text-gray-600">We offer the best car rental experience in Goa</p>
          </div>

          <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4">
            <div className="p-6 text-center bg-white rounded-lg shadow-sm">
              <div className="flex items-center justify-center w-12 h-12 mx-auto mb-4 bg-orange-100 rounded-full">
                <Star className="w-6 h-6 text-orange-500" />
              </div>
              <h3 className="mb-2 text-lg font-medium">Well-Maintained Cars</h3>
              <p className="text-gray-600">All our vehicles are regularly serviced and kept in pristine condition.</p>
            </div>

            <div className="p-6 text-center bg-white rounded-lg shadow-sm">
              <div className="flex items-center justify-center w-12 h-12 mx-auto mb-4 bg-orange-100 rounded-full">
                <Star className="w-6 h-6 text-orange-500" />
              </div>
              <h3 className="mb-2 text-lg font-medium">24/7 Support</h3>
              <p className="text-gray-600">Our customer support team is available round the clock to assist you.</p>
            </div>

            <div className="p-6 text-center bg-white rounded-lg shadow-sm">
              <div className="flex items-center justify-center w-12 h-12 mx-auto mb-4 bg-orange-100 rounded-full">
                <Star className="w-6 h-6 text-orange-500" />
              </div>
              <h3 className="mb-2 text-lg font-medium">Flexible Rental Plans</h3>
              <p className="text-gray-600">Choose from hourly, daily, or weekly rental plans that suit your needs.</p>
            </div>

            <div className="p-6 text-center bg-white rounded-lg shadow-sm">
              <div className="flex items-center justify-center w-12 h-12 mx-auto mb-4 bg-orange-100 rounded-full">
                <Star className="w-6 h-6 text-orange-500" />
              </div>
              <h3 className="mb-2 text-lg font-medium">Affordable Rates</h3>
              <p className="text-gray-600">Competitive pricing with no hidden charges or surprise fees.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 bg-gray-900 text-white">
        <div className="container px-4 mx-auto">
          <div className="flex flex-col items-center mb-12 text-center">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">What Our Customers Say</h2>
            <p className="mt-4 text-lg text-gray-300">Don't just take our word for it</p>
          </div>
          <TestimonialSlider />
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16 bg-white">
        <div className="container px-4 mx-auto">
          <div className="flex flex-col items-center mb-12 text-center">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Get In Touch</h2>
            <p className="mt-4 text-lg text-gray-600">Have questions? Contact us for more information</p>
          </div>

          <div className="grid grid-cols-1 gap-8 lg:grid-cols-2">
            <div className="space-y-6">
              <div className="p-6 bg-gray-50 rounded-lg">
                <h3 className="mb-4 text-xl font-medium">Contact Information</h3>
                <div className="space-y-4">
                  <div className="flex items-start">
                    <MapPin className="w-5 h-5 mt-1 mr-3 text-orange-500" />
                    <div>
                      <p className="font-medium">Address</p>
                      <p className="text-gray-600">123 Beach Road, Calangute, North Goa, 403516</p>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <Phone className="w-5 h-5 mt-1 mr-3 text-orange-500" />
                    <div>
                      <p className="font-medium">Phone</p>
                      <Link href="tel:+919876543210" className="text-gray-600 hover:text-orange-500">
                        +91 98765 43210
                      </Link>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <Mail className="w-5 h-5 mt-1 mr-3 text-orange-500" />
                    <div>
                      <p className="font-medium">Email</p>
                      <Link href="mailto:info@goacarrentals.com" className="text-gray-600 hover:text-orange-500">
                        info@goacarrentals.com
                      </Link>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <WhatsApp className="w-5 h-5 mt-1 mr-3 text-orange-500" />
                    <div>
                      <p className="font-medium">WhatsApp</p>
                      <Link
                        href="https://wa.me/919876543210?text=I'm%20interested%20in%20renting%20a%20car%20in%20Goa"
                        className="text-gray-600 hover:text-orange-500"
                      >
                        +91 98765 43210
                      </Link>
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-6 bg-gray-50 rounded-lg">
                <h3 className="mb-4 text-xl font-medium">Business Hours</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Monday - Friday:</span>
                    <span>8:00 AM - 8:00 PM</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Saturday:</span>
                    <span>9:00 AM - 7:00 PM</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Sunday:</span>
                    <span>10:00 AM - 6:00 PM</span>
                  </div>
                </div>
              </div>
            </div>

            <ContactForm />
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 bg-orange-500 text-white">
        <div className="container px-4 mx-auto text-center">
          <h2 className="mb-4 text-2xl font-bold sm:text-3xl">Ready to explore Goa?</h2>
          <p className="mb-8 text-lg">Book your car now and get the best rates!</p>
          <div className="flex flex-col justify-center space-y-4 sm:flex-row sm:space-y-0 sm:space-x-4">
            <Button size="lg" variant="outline" className="border-white hover:bg-white hover:text-orange-500">
              <Phone className="w-5 h-5 mr-2" />
              <Link href="tel:+919876543210">Call Now</Link>
            </Button>
            <Button size="lg" className="bg-white text-orange-500 hover:bg-gray-100">
              <WhatsApp className="w-5 h-5 mr-2" />
              <Link href="https://wa.me/919876543210?text=I'm%20interested%20in%20renting%20a%20car%20in%20Goa">
                WhatsApp Now
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
