"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Car, Users, Fuel, Settings } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { getCars } from "@/lib/cars"
import type { CarType } from "@/types/car"

export function FeaturedCars() {
  const [cars, setCars] = useState<CarType[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function loadCars() {
      try {
        const featuredCars = await getCars(true)
        setCars(featuredCars.slice(0, 6))
      } catch (error) {
        console.error("Failed to load cars:", error)
      } finally {
        setLoading(false)
      }
    }

    loadCars()
  }, [])

  if (loading) {
    return (
      <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
        {[...Array(6)].map((_, i) => (
          <Card key={i} className="overflow-hidden">
            <div className="w-full h-48 bg-gray-200 animate-pulse"></div>
            <CardContent className="p-6">
              <div className="w-2/3 h-6 mb-4 bg-gray-200 animate-pulse"></div>
              <div className="w-full h-4 mb-2 bg-gray-200 animate-pulse"></div>
              <div className="w-full h-4 mb-2 bg-gray-200 animate-pulse"></div>
              <div className="w-3/4 h-4 bg-gray-200 animate-pulse"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }

  // Fallback data if no cars are loaded
  if (cars.length === 0) {
    const fallbackCars = [
      {
        id: "1",
        name: "Toyota Innova Crysta",
        image: "/images/innova.jpg",
        price: 3500,
        seats: 7,
        transmission: "Automatic",
        fuelType: "Diesel",
        featured: true,
      },
      {
        id: "2",
        name: "Maruti Swift",
        image: "/images/swift.jpg",
        price: 1500,
        seats: 5,
        transmission: "Manual",
        fuelType: "Petrol",
        featured: true,
      },
      {
        id: "3",
        name: "Hyundai Creta",
        image: "/images/creta.jpg",
        price: 2500,
        seats: 5,
        transmission: "Automatic",
        fuelType: "Petrol",
        featured: true,
      },
    ]
    setCars(fallbackCars as CarType[])
  }

  return (
    <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
      {cars.map((car) => (
        <Card key={car.id} className="overflow-hidden transition-all duration-300 hover:shadow-lg">
          <div className="relative w-full h-48">
            <Image src={car.image || "/images/car-placeholder.jpg"} alt={car.name} fill className="object-cover" />
            {car.featured && <Badge className="absolute top-2 right-2 bg-orange-500">Featured</Badge>}
          </div>
          <CardContent className="p-6">
            <h3 className="mb-2 text-xl font-bold">{car.name}</h3>
            <p className="mb-4 text-2xl font-bold text-orange-500">₹{car.price}/day</p>

            <div className="grid grid-cols-2 gap-4 mb-4">
              <div className="flex items-center">
                <Users className="w-5 h-5 mr-2 text-gray-500" />
                <span>{car.seats} Seats</span>
              </div>
              <div className="flex items-center">
                <Settings className="w-5 h-5 mr-2 text-gray-500" />
                <span>{car.transmission}</span>
              </div>
              <div className="flex items-center">
                <Fuel className="w-5 h-5 mr-2 text-gray-500" />
                <span>{car.fuelType}</span>
              </div>
              <div className="flex items-center">
                <Car className="w-5 h-5 mr-2 text-gray-500" />
                <span>A/C</span>
              </div>
            </div>
          </CardContent>
          <CardFooter className="p-6 pt-0">
            <div className="flex flex-col w-full space-y-2 sm:flex-row sm:space-y-0 sm:space-x-2">
              <Button asChild variant="outline" className="flex-1">
                <Link href={`/cars/${car.id}`}>Details</Link>
              </Button>
              <Button asChild className="flex-1 bg-orange-500 hover:bg-orange-600">
                <Link href={`https://wa.me/919876543210?text=I'm%20interested%20in%20renting%20the%20${car.name}`}>
                  Book Now
                </Link>
              </Button>
            </div>
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}
