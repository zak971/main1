import Link from "next/link"
import Image from "next/image"
import { Phone, Mail, MapPin, Facebook, Instagram, Twitter } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="container px-4 py-12 mx-auto">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4">
          <div>
            <Link href="/" className="inline-block mb-6">
              <Image
                src="/images/logo-white.png"
                alt="Goa Car Rentals"
                width={150}
                height={40}
                className="h-10 w-auto"
              />
            </Link>
            <p className="mb-6">
              Premium car rental service in Goa offering well-maintained vehicles at affordable prices. Experience the
              beauty of Goa with comfort and style.
            </p>
            <div className="flex space-x-4">
              <Link href="#" className="hover:text-white">
                <Facebook className="w-5 h-5" />
                <span className="sr-only">Facebook</span>
              </Link>
              <Link href="#" className="hover:text-white">
                <Instagram className="w-5 h-5" />
                <span className="sr-only">Instagram</span>
              </Link>
              <Link href="#" className="hover:text-white">
                <Twitter className="w-5 h-5" />
                <span className="sr-only">Twitter</span>
              </Link>
            </div>
          </div>

          <div>
            <h3 className="mb-6 text-lg font-semibold text-white">Quick Links</h3>
            <ul className="space-y-3">
              <li>
                <Link href="/" className="hover:text-white">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/cars" className="hover:text-white">
                  Our Cars
                </Link>
              </li>
              <li>
                <Link href="/about" className="hover:text-white">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/#contact" className="hover:text-white">
                  Contact
                </Link>
              </li>
              <li>
                <Link href="/terms" className="hover:text-white">
                  Terms & Conditions
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="hover:text-white">
                  Privacy Policy
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="mb-6 text-lg font-semibold text-white">Our Cars</h3>
            <ul className="space-y-3">
              <li>
                <Link href="/cars?type=economy" className="hover:text-white">
                  Economy Cars
                </Link>
              </li>
              <li>
                <Link href="/cars?type=sedan" className="hover:text-white">
                  Sedans
                </Link>
              </li>
              <li>
                <Link href="/cars?type=suv" className="hover:text-white">
                  SUVs
                </Link>
              </li>
              <li>
                <Link href="/cars?type=luxury" className="hover:text-white">
                  Luxury Cars
                </Link>
              </li>
              <li>
                <Link href="/cars?type=minivan" className="hover:text-white">
                  Minivans
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="mb-6 text-lg font-semibold text-white">Contact Us</h3>
            <ul className="space-y-4">
              <li className="flex">
                <MapPin className="w-5 h-5 mr-3 text-orange-500 shrink-0" />
                <span>123 Beach Road, Calangute, North Goa, 403516</span>
              </li>
              <li className="flex">
                <Phone className="w-5 h-5 mr-3 text-orange-500 shrink-0" />
                <Link href="tel:+919876543210" className="hover:text-white">
                  +91 98765 43210
                </Link>
              </li>
              <li className="flex">
                <Mail className="w-5 h-5 mr-3 text-orange-500 shrink-0" />
                <Link href="mailto:info@goacarrentals.com" className="hover:text-white">
                  info@goacarrentals.com
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-8 mt-8 border-t border-gray-800">
          <div className="flex flex-col items-center justify-between space-y-4 md:flex-row md:space-y-0">
            <p>&copy; {new Date().getFullYear()} Goa Car Rentals. All rights reserved.</p>
            <p>Designed with ❤️ for the beautiful beaches of Goa</p>
          </div>
        </div>
      </div>
    </footer>
  )
}
