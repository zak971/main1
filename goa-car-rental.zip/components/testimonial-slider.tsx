"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { ChevronLeft, ChevronRight, Star } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

type Testimonial = {
  id: number
  name: string
  location: string
  image: string
  rating: number
  text: string
}

const testimonials: Testimonial[] = [
  {
    id: 1,
    name: "Rahul Sharma",
    location: "Delhi",
    image: "/images/testimonial-1.jpg",
    rating: 5,
    text: "Amazing service! The car was in perfect condition and the staff was very helpful. Will definitely rent again when I'm back in Goa.",
  },
  {
    id: 2,
    name: "Priya Patel",
    location: "Mumbai",
    image: "/images/testimonial-2.jpg",
    rating: 5,
    text: "We rented an Innova for our family trip and it was a great experience. The car was clean and well-maintained. The pickup and drop-off process was smooth.",
  },
  {
    id: 3,
    name: "Michael Brown",
    location: "UK",
    image: "/images/testimonial-3.jpg",
    rating: 4,
    text: "Very professional service. The car was delivered on time to our hotel and the rates were reasonable. Would recommend to other tourists.",
  },
  {
    id: 4,
    name: "Anjali Desai",
    location: "Bangalore",
    image: "/images/testimonial-4.jpg",
    rating: 5,
    text: "Best car rental in Goa! We got a Swift and it was perfect for exploring the narrow roads. The staff was friendly and responsive on WhatsApp.",
  },
]

export function TestimonialSlider() {
  const [current, setCurrent] = useState(0)
  const [autoplay, setAutoplay] = useState(true)

  const next = () => {
    setCurrent((current + 1) % testimonials.length)
  }

  const prev = () => {
    setCurrent((current - 1 + testimonials.length) % testimonials.length)
  }

  useEffect(() => {
    if (!autoplay) return

    const interval = setInterval(() => {
      next()
    }, 5000)

    return () => clearInterval(interval)
  }, [current, autoplay])

  return (
    <div className="relative">
      <div className="overflow-hidden">
        <div
          className="flex transition-transform duration-500 ease-in-out"
          style={{ transform: `translateX(-${current * 100}%)` }}
        >
          {testimonials.map((testimonial) => (
            <div key={testimonial.id} className="w-full flex-shrink-0 px-4">
              <Card className="bg-gray-800 border-gray-700">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <div className="relative w-12 h-12 mr-4 overflow-hidden rounded-full">
                      <Image
                        src={testimonial.image || "/images/avatar-placeholder.jpg"}
                        alt={testimonial.name}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div>
                      <h4 className="font-medium">{testimonial.name}</h4>
                      <p className="text-sm text-gray-400">{testimonial.location}</p>
                    </div>
                    <div className="flex ml-auto">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${i < testimonial.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-600"}`}
                        />
                      ))}
                    </div>
                  </div>
                  <p className="text-gray-300">{testimonial.text}</p>
                </CardContent>
              </Card>
            </div>
          ))}
        </div>
      </div>

      <Button
        variant="outline"
        size="icon"
        className="absolute left-0 z-10 -translate-y-1/2 bg-white/10 border-gray-700 text-white hover:bg-white/20 top-1/2"
        onClick={prev}
      >
        <ChevronLeft className="w-5 h-5" />
        <span className="sr-only">Previous</span>
      </Button>

      <Button
        variant="outline"
        size="icon"
        className="absolute right-0 z-10 -translate-y-1/2 bg-white/10 border-gray-700 text-white hover:bg-white/20 top-1/2"
        onClick={next}
      >
        <ChevronRight className="w-5 h-5" />
        <span className="sr-only">Next</span>
      </Button>
    </div>
  )
}
