import type { CarType } from "@/types/car"

// Mock data for cars
const carsData: CarType[] = [
  {
    id: "1",
    name: "Toyota Innova Crysta",
    image: "/images/innova.jpg",
    price: 3500,
    seats: 7,
    transmission: "Automatic",
    fuelType: "Diesel",
    featured: true,
  },
  {
    id: "2",
    name: "Maruti Swift",
    image: "/images/swift.jpg",
    price: 1500,
    seats: 5,
    transmission: "Manual",
    fuelType: "Petrol",
    featured: true,
  },
  {
    id: "3",
    name: "Hyundai Creta",
    image: "/images/creta.jpg",
    price: 2500,
    seats: 5,
    transmission: "Automatic",
    fuelType: "Petrol",
    featured: true,
  },
  {
    id: "4",
    name: "Mahindra Thar",
    image: "/images/thar.jpg",
    price: 3000,
    seats: 4,
    transmission: "Manual",
    fuelType: "Diesel",
    featured: false,
  },
  {
    id: "5",
    name: "Honda City",
    image: "/images/city.jpg",
    price: 2200,
    seats: 5,
    transmission: "Automatic",
    fuelType: "Petrol",
    featured: false,
  },
  {
    id: "6",
    name: "Maruti Ertiga",
    image: "/images/ertiga.jpg",
    price: 2800,
    seats: 7,
    transmission: "Manual",
    fuelType: "Petrol",
    featured: false,
  },
]

// In a real application, these functions would interact with a database
export async function getCars(featuredOnly = false): Promise<CarType[]> {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 500))

  if (featuredOnly) {
    return carsData.filter((car) => car.featured)
  }

  return carsData
}

export async function getCar(id: string): Promise<CarType | null> {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 300))

  const car = carsData.find((car) => car.id === id)
  return car || null
}

export async function addCar(car: Omit<CarType, "id">): Promise<CarType> {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 800))

  const newCar = {
    ...car,
    id: Math.random().toString(36).substring(2, 9),
  }

  carsData.push(newCar)
  return newCar
}

export async function updateCar(id: string, car: Partial<CarType>): Promise<CarType> {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 800))

  const index = carsData.findIndex((c) => c.id === id)

  if (index === -1) {
    throw new Error("Car not found")
  }

  carsData[index] = { ...carsData[index], ...car }
  return carsData[index]
}

export async function deleteCar(id: string): Promise<void> {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 800))

  const index = carsData.findIndex((c) => c.id === id)

  if (index === -1) {
    throw new Error("Car not found")
  }

  carsData.splice(index, 1)
}
