export type CarType = {
  id: string
  name: string
  image?: string
  price: number
  seats: number
  transmission: string
  fuelType: string
  featured?: boolean
}
